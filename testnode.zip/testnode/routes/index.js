var express = require('express');
var router = express.Router();
var mysql = require("mysql");
var con = mysql.createConnection({
  host: "203.154.83.62",
  user: "loph",
  password: "161042",
  database: "db_loph"
});
con.connect(function(err){
  if(err){
    console.log('Error connecting to Db');
    return;
  }
  console.log('Connection established');
  con.query('SELECT * FROM account_user', function(error, results, fields) {
    if(error) throw error;
    console.log(results);		
});
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/show', function(request, response) {
  connection.query('SELECT * FROM account ', function(error, results, fields) {
          if(error) throw error;
          console.log(results);		
    response.end();
  });

});

module.exports = router;
